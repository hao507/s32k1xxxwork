#include "timer.h"
#include "device_registers.h" /* include peripheral declarations S32K144 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define TIMER_MAX	10
#define TIMER_OUT	1
static int timerNum = 0, timerMax = 0, heartbeat = 0;
static int timer[TIMER_MAX] = {0}, timerFlag[TIMER_MAX] = {0};


void LPTMR_init()//1ms
{
    PCC->PCCn[PCC_LPTMR0_INDEX] = PCC_PCCn_CGC_MASK;	/* Enable LPTMR Clock 		*/
    LPTMR0->PSR |= LPTMR_PSR_PCS(0b01)                  /* LPTMR clk src: 1KHz LPO */
                  |LPTMR_PSR_PBYP_MASK;               	/* Bypass Prescaler 		*/
    LPTMR0->CMR = 1;//time_ms - 1;                                  /* 500 ms interrupt 		*/
    LPTMR0->CSR |= LPTMR_CSR_TIE_MASK; 					/* Timer interrupt enabled */
    LPTMR0->CSR |= LPTMR_CSR_TEN_MASK;                  /* Enable Timer 			*/
}

int  TimerCreate(unsigned int time_ms){
	int i = 0, temp = 0;
	for(i=0; i < timerNum; i++){
		if(timer[i] == time_ms)
			return -2;
	}
	if(timerNum < TIMER_MAX)
		timer[timerNum++] = time_ms;
	else
		return -1;
	for(i=0; i< timerNum; i++){
		if(i>0){
			if(timer[i] > timer[i-1] && timer[i] > temp){
				temp = timer[i];
				timerMax = i;
			}
		}
	}
	return 0;
}

int  TimerDelete(unsigned int time_ms){
	int i = 0;
	for(i=0; i< timerNum; i++){
		if(timer[i] == time_ms){
			memcpy(timer+i, timer+i+1, sizeof(int)*(timerNum - i - 1));
			return 0;
		}
	}
	return -1;
}

void LPTMR0_IRQHandler (void)
{
	if(0!=(LPTMR0->CSR & LPTMR_CSR_TCF_MASK))
	{
		/* Check if TCF flag is set */
		LPTMR0->CSR |= LPTMR_CSR_TCF_MASK;	/*	Clear TCF flag by writting a logic one */
		heartbeat++;
		int i = 0;
		for(i=0; i< timerNum; i++){
			if(heartbeat == timer[i]){
				timerFlag[i] = TIMER_OUT;
			}
		}
		if(heartbeat == timer[timerMax])
			heartbeat = 0;
	}
}
