/*
 * clocks_and_modes.h
 *
 *  Created on: 2019��5��15��
 *      Author: Administrator
 */

#ifndef NXPLIB_CLOCKS_AND_MODES_H_
#define NXPLIB_CLOCKS_AND_MODES_H_

void SOSC_init_8MHz (void);
void SPLL_init_160MHz (void);
void NormalRUNmode_80MHz (void);

#endif /* NXPLIB_CLOCKS_AND_MODES_H_ */
