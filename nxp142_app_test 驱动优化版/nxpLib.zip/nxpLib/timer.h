#ifndef NXPLIB_TIMER_H_
#define NXPLIB_TIMER_H_

void LPTMR_init();
int  TimerCreate(unsigned int time_ms);
int  TimerDelete(unsigned int time_ms);

#endif
